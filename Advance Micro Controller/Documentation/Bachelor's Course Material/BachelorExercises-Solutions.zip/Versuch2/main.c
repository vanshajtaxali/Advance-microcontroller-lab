#include <msp430.h> 
#include <templateEMP.h>

/*
 * main.c
 */

char redHasBlinked = 0;
volatile char button5pressed = 0;
char button6pressed = 0;

int counter = 0;
char inputRegister;

void initPins(void);

int main(void) {
	initMSP();

	initPins();

	// Enable interrupts:
	__enable_interrupt();

	while (1) {

		//***************************
		// Read the button state:
		//***************************

		inputRegister = P1IN;

//		// Check PB5:
//		if( ( inputRegister & BIT3 ) == 0) {
//			// BB5 was pressed:
//			button5pressed = 1;
//		} else {
//			// PB5 not pressed:
//
//			// Check if just being a low glitch due to bad button:
//			// 1. Wait for 200 ms:
//			__delay_cycles(200000);
//			// 2. Check again:
//			if( ( P1IN & BIT3 ) != 0) {
//				// Button was really released:
//				button5pressed = 0;
//				// Button was release for sure since the last activation:
//				redHasBlinked = 0;
//			}
//		}

		// Check PB6:
		if( ( inputRegister & BIT4 ) == 0) {
			// BB6 was pressed:
			button6pressed = 1;
		} else {
			// Button was released:
			button6pressed = 0;
		}

		//***************************
		// Set the LEDs:
		//***************************

		// Handle the blue LED:
		if(button5pressed && button6pressed) {
			P1OUT |= BIT0;
		} else {
			P1OUT &= ~BIT0;
		}

		// Handle the red and yellow LED:
		if(button5pressed && !redHasBlinked) {
			// Briefly flash the red and yellow LED:
			P1OUT |= BIT5;
			P1OUT &= ~BIT7;
			__delay_cycles(200000);
			P1OUT &= ~BIT5;
			P1OUT |= BIT7;
			// Set a flag storing the information that red has blinked once:
			redHasBlinked = 1;
		}

		// Handle the green LED:
		if(button6pressed) {
			P1OUT |= BIT6;
		} else {
			P1OUT &= ~BIT6;
		}

	}
}

void initPins(void) {
	// Initialize P1.0, P1.5, P1.6 and P1.7 as output,
	// while the rest of the pins are kept as input:
	P1DIR |= (BIT0 | BIT5 | BIT6 | BIT7);
	// Set all outputs to zero, except for that of the yellow LED:
	P1OUT = 0;
	P1OUT |= BIT7;
	// Set pullup resistors for P1.3 and P1.4:
	P1REN |= (BIT3 | BIT4);
	P1OUT |= (BIT3 | BIT4);

	// Set the interrupts for P1.5
	P1IE |= BIT3 ; // Enable interrupt
	P1IES |= BIT3 ; // Interrupt triggered on HIGH to LOW edge
	P1IFG &= ~ BIT3 ; // Clear interrupt flag
}


// Port 1 interrupt vector
# pragma vector = PORT1_VECTOR
__interrupt void Port_1 ( void ) {
	// Any button change occured, maybe just a glitch, so wait for settling:
	__delay_cycles(20000);

	if( (button5pressed == 0) ) {
		// Button was released before:
		if( ( P1IN & BIT3 ) == 0) {
			// BB5 is pressed:
			button5pressed = 1;
			// now react on LOW to HIGH transition:
			P1IES &= ~BIT3 ;
		}
	} else {
		// Button was pressed before:
		if( ( P1IN & BIT3 ) != 0) {
			// BB5 is released:
			button5pressed = 0;
			redHasBlinked = 0;
			// now react on HIGH to LOW transition:
			P1IES |= BIT3 ;
		}

	}

	// Clear interrupt flag ( here - as an example - the flag of P1 .0).
	P1IFG &= ~ BIT3 ;
}
