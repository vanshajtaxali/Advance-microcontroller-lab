#include <templateEMP.h>

/*
 * main.c
 * This is the solution for exercise 1, Mikrocomputertechnik-Lab 1
 *
 * Author:
 * Sebastian Sester <sebastian.sester@imtek.de>
 *
 */

/*
 * The blue LED is connected to ___.
 * It also controls the ___ when ___.
 */

void main(void) {
    initMSP();
	P1DIR |= BIT4 | BIT5;
	P1OUT &= ~(BIT4 | BIT5);
	
	while(1) {
		P1OUT ^= BIT4;
		__delay_cycles(250000);
		P1OUT ^= BIT4;
		P1OUT ^= BIT5;
		__delay_cycles(250000);

		if (serialAvailable()) {
			serialFlush();
			if (P1OUT & BIT5) {
				serialPrintln("Blaue LED an.");
			}
			else {
				serialPrintln("Blaue LED aus.");
			}
		}
	}
}
