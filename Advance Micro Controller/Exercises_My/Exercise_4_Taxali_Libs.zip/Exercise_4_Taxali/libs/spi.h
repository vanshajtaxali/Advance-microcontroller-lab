/***************************************************************************//**
 * @file    spi.h
 * @author  <VANSHAJ TAXALI>
 * @Email   <vanshajtaxali94@gmail.com>
 * @date    <14-06-2018>
 *
 * @brief   <brief description>
 *
 * Here goes a detailed description if required.
 ******************************************************************************/

#ifndef LIBS_SPI_H_
#define LIBS_SPI_H_

/******************************************************************************
 * INCLUDES
 *****************************************************************************/

#include <msp430g2553.h>

/******************************************************************************
 * CONSTANTS
 *****************************************************************************/
#define F_HOLD              BIT3    //P3.3
#define F_CHIP_SELECT       BIT4    //P3.4
#define F_WRITE_PROTECT     BIT5    //P3.5
#define F_SERIAL_CLOCK      BIT5    //P1.5
#define DATA_IN             BIT6    //P1.6
#define DATA_OUT            BIT7    //P1.7
#define I2C_SPI             BIT3    //P1.3


/******************************************************************************
 * VARIABLES
 *****************************************************************************/



/******************************************************************************
 * FUNCTION PROTOTYPES
 *****************************************************************************/

// Set the USCI-machine to SPI and switch the 74HCT4066 (1 pt.)
void spi_init(void);

// Read <length> bytes into <rxData> (1 pt.)
void spi_read(unsigned char length, unsigned char * rxData);

// Write <length> bytes from <txData> (1 pt.)
void spi_write(unsigned char length, unsigned char * txData);

// Interrupt service routines in your spi.c (1 pt.)

// Returns 1 if the SPI is still busy or 0 if not.
// Note: this is optional. You will most likely need this, but you don't have
// to implement or use this.
unsigned char spi_busy(void);

#endif /* LIBS_SPI_H_ */
